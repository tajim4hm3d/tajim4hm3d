import {verifyOwner} from '../_lib/auth.js';
export async function onRequest(context) {
  const result=await verifyOwner(context);
  if (result.response) return result.response;
  context.data.owner=result.identity;
  const response=await context.next();
  const headers=new Headers(response.headers);headers.set('Cache-Control','no-store');headers.set('X-Robots-Tag','noindex,nofollow');
  return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
