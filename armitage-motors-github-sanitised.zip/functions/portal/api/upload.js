import {json,problem} from '../../_lib/data.js';
export async function onRequestPost(context){
  if(context.request.headers.get('X-Northstar-Portal')!=='1')return problem('Invalid request.',403);
  const bucket=context.env.IMAGES;
  if(!bucket)return problem('Photo uploads are not configured yet. Create an R2 bucket and bind it as IMAGES.',503);
  try {
    const form=await context.request.formData(),file=form.get('file');
    if(!file||typeof file.arrayBuffer!=='function')return problem('No photo was provided.');
    if(file.size<10||file.size>10*1024*1024)return problem('Photo must be smaller than 10 MB.');
    const mime=file.type;
    if(!['image/jpeg','image/png','image/webp'].includes(mime))return problem('Use JPG, PNG or WebP files.');
    const data=await file.arrayBuffer(),head=new Uint8Array(data.slice(0,16));
    const jpg=head[0]===0xff&&head[1]===0xd8&&head[2]===0xff;
    const png=head[0]===137&&head[1]===80&&head[2]===78&&head[3]===71;
    const webp=String.fromCharCode(...head.slice(0,4))==='RIFF'&&String.fromCharCode(...head.slice(8,12))==='WEBP';
    if(!((mime==='image/jpeg'&&jpg)||(mime==='image/png'&&png)||(mime==='image/webp'&&webp)))return problem('This file does not appear to be a valid image.');
    const ext=mime==='image/png'?'png':mime==='image/webp'?'webp':'jpg';
    const id=String(form.get('carId')||'new').replace(/[^0-9]/g,'').slice(0,20)||'new';
    const key=`cars/${id}/${crypto.randomUUID()}.${ext}`;
    await bucket.put(key,data,{httpMetadata:{contentType:mime},customMetadata:{uploadedBy:'northstar-portal'}});
    return json({url:'/media/'+key});
  }catch(e){console.error(e);return problem('Photo upload failed.',503);}
}
