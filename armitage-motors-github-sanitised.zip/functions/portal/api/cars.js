import {json,problem,dbFrom,listCars,saveCar} from '../../_lib/data.js';
export async function onRequestGet(context){try{return json({cars:await listCars(dbFrom(context),true)});}catch(e){console.error(e);return problem('Could not read D1 vehicle stock.',503);}}
export async function onRequestPost(context){
  if(context.request.headers.get('X-Northstar-Portal')!=='1')return problem('Invalid request',403);
  try{
    const car=await saveCar(dbFrom(context),await context.request.json());
    return json({car});
  }catch(e){console.error(e);return problem(e.message||'Could not save car.',400);}
}
