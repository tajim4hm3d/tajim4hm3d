import {json,problem,dbFrom,saveCar} from '../../_lib/data.js';
export async function onRequestPost(context){
  if(context.request.headers.get('X-Northstar-Portal')!=='1')return problem('Invalid request.',403);
  try{
    const db=dbFrom(context), input=await context.request.json(), list=input.cars;
    if(!Array.isArray(list)||list.length>20)return problem('Invalid starter stock.');
    const count=await db.prepare('SELECT COUNT(*) AS n FROM cars').first();
    if(Number(count?.n)!==0)return problem('Import only works with an empty database.');
    for(const car of list)await saveCar(db,car);
    return json({imported:list.length});
  }catch(e){console.error(e);return problem(e.message||'Import failed.',400);}
}
