import {json,problem,dbFrom} from '../../../_lib/data.js';
export async function onRequestDelete(context){
  if(context.request.headers.get('X-Northstar-Portal')!=='1')return problem('Invalid request.',403);
  const id=Number(context.params.id);if(!Number.isSafeInteger(id)||id<=0)return problem('Invalid vehicle ID.');
  try{const db=dbFrom(context);await db.batch([db.prepare('DELETE FROM car_photos WHERE car_id=?').bind(id),db.prepare('DELETE FROM cars WHERE id=?').bind(id)]);return json({deleted:true,id});}
  catch(e){console.error(e);return problem('Unable to delete this car.',503);}
}
