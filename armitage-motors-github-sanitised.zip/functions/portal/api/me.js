import {json} from '../../_lib/data.js';
export function onRequestGet(context){return json({user:context.data.owner});}
