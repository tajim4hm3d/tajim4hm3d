// Public customer enquiries. This route does not touch D1/R2 or the owner portal.
// Provider: Resend. Abuse protection: mandatory server-side Cloudflare Turnstile.
const allowedTypes = new Set([
  'General enquiry', 'Vehicle enquiry', 'Part exchange', 'Finding a vehicle',
  'Sell my car', 'Nationwide delivery', 'Vehicle sourcing', 'Number plates', 'Vehicle warranty'
]);
const emailRegex = /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/;
const reply = (message, status=400) => Response.json({ok:false,error:message},{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const text = (obj, key, len=100) => typeof obj?.[key] === 'string' ? obj[key].trim().slice(0,len) : '';
function integerOrBlank(value, min, max) {
  if (value === undefined || value === null || value === '') return '';
  const n=Number(value);
  if (!Number.isInteger(n) || n<min || n>max) throw Error('Invalid numerical vehicle information.');
  return String(n);
}
function requiredSetting(env, name) {return typeof env[name] === 'string' && env[name].trim() ? env[name].trim() : null;}
export async function onRequestPost({request,env}) {
  const to=requiredSetting(env,'ENQUIRY_TO_EMAIL');
  const from=requiredSetting(env,'ENQUIRY_FROM_EMAIL');
  const resendKey=requiredSetting(env,'RESEND_API_KEY');
  const turnstileSecret=requiredSetting(env,'TURNSTILE_SECRET_KEY');
  const siteKey=requiredSetting(env,'TURNSTILE_SITE_KEY');
  if (!to || !from || !resendKey || !turnstileSecret || !siteKey) return reply('Online enquiries are being configured. Please call (demo number not supplied).',503);
  if (!emailRegex.test(to) || !/^(.+ <)?[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+>?$/.test(from)) return reply('Online enquiries are temporarily unavailable. Please call us.',503);
  if (!/^application\/json(?:;|$)/i.test(request.headers.get('content-type') || '')) return reply('Unsupported request format.',415);
  if (Number(request.headers.get('content-length') || 0)>12000) return reply('Enquiry is too long.',413);
  const host=new URL(request.url).hostname.toLowerCase();
  const origin=request.headers.get('origin');
  if (origin) { try {if(new URL(origin).hostname.toLowerCase()!==host) return reply('This request must be submitted from our website.',403);} catch{return reply('Invalid request origin.',403);} }
  let data;
  try { const body=await request.text(); if(body.length>12000) return reply('Enquiry is too long.',413); data=JSON.parse(body); }
  catch {return reply('Invalid form details. Please try again.');}
  if(!data || typeof data!=='object' || Array.isArray(data)) return reply('Invalid form details.');
  // Do not silently report success for honeypot matches: browser autofill can populate hidden fields.
  // A response must never say ok:true unless Resend accepted the email.
  if (text(data,'website',200)) return reply('Your enquiry could not be processed. Please refresh the form and try again.');
  const kind=text(data,'kind',20);
  if(!['contact','valuation'].includes(kind)) return reply('Unknown enquiry form.');
  const name=text(data,'name',100), phone=text(data,'phone',35), email=text(data,'email',150);
  const type=text(data,'type',40);
  if(!name || name.length<2 || !phone || phone.length<7 || !/^[0-9+() .-]{7,35}$/.test(phone)) return reply('Please enter your name and a valid phone number.');
  if(email && !emailRegex.test(email)) return reply('Please enter a valid email address.');
  if(kind==='contact' && !email) return reply('Please enter your email address.');
  if(!allowedTypes.has(type)) return reply('Please choose an enquiry type.');
  if(kind==='valuation' && !['Sell my car','Part exchange'].includes(type)) return reply('Invalid valuation type.');
  const selling=['Sell my car','Part exchange'].includes(type);
  const message=text(data,'message',2000);
  if(kind==='contact' && !selling && !message) return reply('Please enter a message.');
  const fields=[['Name',name],['Phone',phone],['Email',email||'Not supplied'],['Enquiry type',type]];
  if(selling){
    const registration=text(data,'registration',12).toUpperCase(), model=text(data,'model',160), history=text(data,'history',80), condition=text(data,'condition',1400);
    if(!model) return reply('Please enter your vehicle make, model and specification.');
    let mileage, price, year;
    try {mileage=integerOrBlank(data.mileage,0,2000000); price=integerOrBlank(data.price,0,10000000); year=integerOrBlank(data.year,1886,2100);}
    catch {return reply('Please check the vehicle year, mileage and asking price.');}
    if(kind==='valuation' && (!registration || !history || !mileage || !price)) return reply('Please complete the registration, mileage, service history and guideline price.');
    fields.push(['Registration',registration||'Not supplied'],['Make/model/specification',model],['Year',year||'Not supplied'],['Mileage',mileage?mileage+' miles':'Not supplied'],['Service history',history||'Not supplied'],['Condition',condition||'Not supplied'],['Guideline price',price?'£'+price:'Not supplied']);
    if(kind==='valuation')fields.push(['Vehicle interested in',text(data,'target',120)||'Not supplied']);
  }
  fields.push(['Message',message||'Not supplied']);
  const token=text(data,'turnstileToken',2048);
  if (!token) return reply('Please complete the security check.',400);
  let verified;
  try {
    const params=new URLSearchParams({secret:turnstileSecret,response:token});
    const ip=request.headers.get('CF-Connecting-IP');if(ip)params.set('remoteip',ip);
    const response=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:params,signal:AbortSignal.timeout(8000)});
    if(!response.ok) return reply('Security verification is temporarily unavailable. Please try again.',503);
    verified=await response.json();
  } catch {return reply('Security verification is temporarily unavailable. Please try again.',503);}
  if (!verified?.success || String(verified.hostname||'').toLowerCase()!==host) return reply('Security check failed or expired. Please try again.',403);
  // Always keep customer-supplied text out of email headers except a validated reply_to.
  const subject=`[Northstar Motors] ${type} — ${name}`.replace(/[\r\n]/g,' ').slice(0,180);
  const body=['New website enquiry','',...fields.map(([label,value])=>`${label}: ${value}`),'','Received via Northstar Motors website. Reply to the customer directly using their supplied contact details.'].join('\n');
  const idempotency=text(data,'submissionId',100);
  const headers={'Authorization':`Bearer ${resendKey}`,'Content-Type':'application/json'};
  if(/^[a-zA-Z0-9_-]{12,100}$/.test(idempotency))headers['Idempotency-Key']=`northstar-${idempotency}`;
  try {
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers,body:JSON.stringify({from,to:[to],subject,text:body,...(email?{reply_to:email}:{})}),signal:AbortSignal.timeout(10000)});
    if(!response.ok){
      // Log only the provider status and error code (never API keys or customer details).
      let providerCode='unknown';
      try {const failure=await response.json();providerCode=String(failure?.name||failure?.code||'unknown').slice(0,60);} catch {}
      console.error('Resend rejected enquiry:',response.status,providerCode);
      return reply('Your enquiry could not be sent. Please try again or call (demo number not supplied).',502);
    }
    let accepted;
    try {accepted=await response.json();}catch{console.error('Resend returned an unreadable success response');return reply('Your enquiry could not be confirmed. Please call (demo number not supplied).',502);}
    if(typeof accepted?.id!=='string'||!accepted.id.trim()){
      console.error('Resend returned no accepted email ID');
      return reply('Your enquiry could not be confirmed. Please call (demo number not supplied).',502);
    }
    console.log('Northstar enquiry accepted by Resend; ID:',accepted.id);
    return Response.json({ok:true,message:'Your enquiry was accepted for sending.',reference:accepted.id},{headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
  }catch{console.error('Email provider could not be reached');return reply('Your enquiry could not be sent. Please call (demo number not supplied).',503);}
}
