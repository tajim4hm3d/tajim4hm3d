import {json,problem,dbFrom,listCars} from '../_lib/data.js';
export async function onRequestGet(context) {
  try {return json({cars:await listCars(dbFrom(context),false)});}
  catch(error){console.error(error);return problem('Stock database is unavailable. Please try again.',503);}
}
