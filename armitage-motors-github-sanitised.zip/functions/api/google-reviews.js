// Official Google Places API (New), optional. Requires GOOGLE_PLACES_API_KEY and GOOGLE_PLACE_ID.
// Do not cache reviews; Google's Places policy limits storage and requires author attribution.
const makeJson=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function onRequestGet({env}) {
  const key=String(env.GOOGLE_PLACES_API_KEY||'').trim();
  const placeId=String(env.GOOGLE_PLACE_ID||'').trim();
  if(!key||!placeId) return makeJson({configured:false,reviews:[]},200);
  if(!/^[a-zA-Z0-9_-]{8,200}$/.test(placeId)) return makeJson({error:'Invalid place ID'},500);
  try {
    const res=await fetch(`https://places.googleapis.com/v1/places/${encodeURIComponent(placeId)}?languageCode=en`,{
      headers:{'X-Goog-Api-Key':key,'X-Goog-FieldMask':'displayName,rating,userRatingCount,reviews,googleMapsUri'},
      cf:{cacheTtl:0,cacheEverything:false}
    });
    if(!res.ok){console.error('Google Places returned',res.status);return makeJson({error:'Google reviews temporarily unavailable',reviews:[]},502);}
    const place=await res.json();
    return makeJson({
      configured:true,rating:place.rating??null,totalRatings:place.userRatingCount??null,
      googleMapsUrl:place.googleMapsUri||null,
      // Up to five relevance-ranked reviews from Google, with source/author attributions.
      reviews:(place.reviews||[]).slice(0,5).map(r=>({
        text:r.text?.text||r.originalText?.text||'',rating:r.rating??0,
        author:r.authorAttribution?.displayName||'Google reviewer',
        authorUrl:r.authorAttribution?.uri||null,authorPhoto:r.authorAttribution?.photoUri||null,
        date:r.publishTime||null,link:r.googleMapsUri||null
      })).filter(r=>r.text)
    });
  } catch(error){console.error('Google Places unavailable',error);return makeJson({error:'Could not load reviews',reviews:[]},503);}
}
