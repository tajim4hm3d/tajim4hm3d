// Expose only the public Turnstile site key and a readiness flag, never secrets.
export async function onRequestGet({env}) {
  const ready = Boolean(env.ENQUIRY_TO_EMAIL && env.ENQUIRY_FROM_EMAIL && env.RESEND_API_KEY && env.TURNSTILE_SECRET_KEY && env.TURNSTILE_SITE_KEY);
  return Response.json({ ready, siteKey: ready ? env.TURNSTILE_SITE_KEY : null }, {
    headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }
  });
}
