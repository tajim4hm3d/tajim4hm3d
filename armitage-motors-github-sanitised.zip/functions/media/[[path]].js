export async function onRequestGet(context){
  const bucket=context.env.IMAGES;
  if(!bucket)return new Response('Not available',{status:404});
  const path=context.params.path;
  const key=Array.isArray(path)?path.join('/'):String(path||'');
  if(!/^cars\/[0-9]+\/[0-9a-f-]{36}\.(jpg|png|webp)$/.test(key))return new Response('Not found',{status:404});
  const item=await bucket.get(key);
  if(!item)return new Response('Not found',{status:404});
  return new Response(item.body,{headers:{'Content-Type':item.httpMetadata?.contentType||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'public, max-age=86400','ETag':item.httpEtag}});
}
