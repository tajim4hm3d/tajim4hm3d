const unauthorized = message => new Response(message,{status:403,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
function decode(segment) {
  const str=segment.replace(/-/g,'+').replace(/_/g,'/');
  return atob(str.padEnd(Math.ceil(str.length/4)*4,'='));
}
function bytes(segment) {return Uint8Array.from(decode(segment),ch=>ch.charCodeAt(0));}
function parsed(segment) {return JSON.parse(decode(segment));}
export async function verifyOwner(context) {
  const env=context.env;
  const issuer=String(env.ACCESS_TEAM_DOMAIN||'').replace(/\/$/,'');
  const aud=String(env.ACCESS_AUD||'').trim();
  const allow=String(env.OWNER_EMAILS||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
  if (!/^https:\/\/[a-z0-9-]+\.cloudflareaccess\.com$/.test(issuer)||!aud||!allow.length)
    return {response:unauthorized('Owner portal is locked until Cloudflare Access is configured.')};
  const token=context.request.headers.get('cf-access-jwt-assertion');
  if(!token) return {response:unauthorized('Cloudflare Access sign-in required.')};
  const segments=token.split('.');
  if(segments.length!==3)return {response:unauthorized('Invalid session token.')};
  try{
    const header=parsed(segments[0]),payload=parsed(segments[1]);
    const now=Math.floor(Date.now()/1000);
    if(header.alg!=='RS256'||!header.kid||payload.iss!==issuer||!Array.isArray(payload.aud)||!payload.aud.includes(aud)||
       !Number.isFinite(payload.exp)||payload.exp<=now||!Number.isFinite(payload.iat)||payload.iat>now+60||
       (payload.nbf!==undefined&&payload.nbf>now)||!allow.includes(String(payload.email||'').toLowerCase()))
       return {response:unauthorized('Unauthorised owner account or expired session.')};
    const req=await fetch(issuer+'/cdn-cgi/access/certs',{headers:{'Accept':'application/json'}});
    if(!req.ok)throw Error('Cannot load Access signing keys');
    const jwks=await req.json();
    const jwk=(jwks.keys||[]).find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256'));
    if(!jwk)return {response:unauthorized('Access signing key not found.')};
    const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
    const verified=await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,bytes(segments[2]),new TextEncoder().encode(segments[0]+'.'+segments[1]));
    if(!verified)return {response:unauthorized('Invalid Access signature.')};
    return {identity:{email:payload.email,sub:payload.sub}};
  } catch(error) {console.error('Access validation failed',error);return {response:unauthorized('Unable to verify Cloudflare Access session.')};}
}
