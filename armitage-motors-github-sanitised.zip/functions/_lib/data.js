export function json(data, status=200) {
  return Response.json(data, {status, headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export function problem(message, status=400) {return json({error:message},status);}
export function dbFrom(context) {
  if (!context.env.DB) throw Error('D1 binding missing. Bind the database as DB under Pages Settings > Bindings.');
  return context.env.DB;
}
export function parseJSON(source, fallback={}) {try {return JSON.parse(source||'{}');}catch {return fallback;}}
export function oneCar(row, photos=[]) {
  const extras=parseJSON(row.details_json);
  return {...extras,id:Number(row.id),make:row.make,model:row.model,trim:row.trim||'',year:row.year,mileage:row.mileage,price:row.price,fuel:row.fuel||'',gearbox:row.gearbox||'',colour:row.colour||'',description:row.description||'',status:row.status,photos};
}
export async function listCars(db, includeDraft=false){
  const carQuery=includeDraft?
    db.prepare('SELECT * FROM cars ORDER BY created_at DESC, id DESC'):
    db.prepare('SELECT * FROM cars WHERE status IN (?, ?) ORDER BY created_at DESC, id DESC').bind('available','sold');
  const [rows, images]=await Promise.all([carQuery.all(),db.prepare('SELECT car_id, image_url FROM car_photos ORDER BY sort_order ASC, id ASC').all()]);
  const pictures=new Map();
  for(const p of images.results||[]) {if(!pictures.has(p.car_id))pictures.set(p.car_id,[]);pictures.get(p.car_id).push(p.image_url);}
  return (rows.results||[]).map(row=>oneCar(row,pictures.get(row.id)||[]));
}
export function validVehicle(input){
  if (!input || typeof input!=='object' || Array.isArray(input)) throw Error('Invalid car details');
  const text=(key,limit=500)=>String(input[key]??'').trim().slice(0,limit);
  const int=(key,max)=>{if(input[key]===null||input[key]===undefined||input[key]==='')return null;const n=Number(input[key]);if(!Number.isInteger(n)||n<0||n>max)throw Error(`Invalid ${key}`);return n;};
  const id=int('id',Number.MAX_SAFE_INTEGER);
  const make=text('make',60),model=text('model',100);
  if (!make||!model) throw Error('Make and model are required.');
  const status=text('status',20)||'available';
  if(!['available','sold','draft'].includes(status)) throw Error('Invalid availability status');
  const photos=Array.isArray(input.photos)?input.photos.slice(0,40):[];
  const safePhotos=photos.map(x=>String(x).trim()).filter(url=>url.startsWith('/media/')||url.startsWith('assets/')||/^https:\/\/[^\s"<>]+$/.test(url));
  if(photos.length!==safePhotos.length)throw Error('Unsupported photo URL. Upload an image or use HTTPS.');
  const array=(key)=>Array.isArray(input[key])?input[key].slice(0,80).map(s=>String(s).trim().slice(0,400)).filter(Boolean):[];
  const sourceUrl=text('sourceUrl',1000);
  if(sourceUrl&&!/^https:\/\//.test(sourceUrl))throw Error('Source URL must be HTTPS.');
  const details={power:text('power',40),features:array('features'),history:array('history'),sellerNote:text('sellerNote',4000),sourceUrl,isScreenshot:Boolean(input.isScreenshot),isDemo:false};
  const year=int('year',2200), mileage=int('mileage',4000000),price=int('price',100000000);
  if(year!==null&&(year<1886||year>new Date().getFullYear()+2))throw Error('Year is out of range.');
  const desc=text('description',12000);
  return {id,make,model,trim:text('trim',180),year,mileage,price,fuel:text('fuel',50),gearbox:text('gearbox',50),colour:text('colour',100),description:desc,status,photos:safePhotos,details};
}
export async function saveCar(db, input){
  const car=validVehicle(input);
  const id=car.id||Date.now();
  const queries=[db.prepare(`INSERT INTO cars (id,make,model,trim,year,mileage,price,fuel,gearbox,colour,description,status,details_json,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET make=excluded.make, model=excluded.model, trim=excluded.trim,year=excluded.year,mileage=excluded.mileage,
      price=excluded.price,fuel=excluded.fuel,gearbox=excluded.gearbox,colour=excluded.colour,description=excluded.description,status=excluded.status,
      details_json=excluded.details_json,updated_at=CURRENT_TIMESTAMP`)
    .bind(id,car.make,car.model,car.trim,car.year,car.mileage,car.price,car.fuel,car.gearbox,car.colour,car.description,car.status,JSON.stringify(car.details)),
    db.prepare('DELETE FROM car_photos WHERE car_id=?').bind(id)];
  for (let i=0; i<car.photos.length; i++) queries.push(db.prepare('INSERT INTO car_photos(car_id,image_url,sort_order) VALUES (?,?,?)').bind(id,car.photos[i],i));
  await db.batch(queries);
  return {...car,...car.details,id};
}
