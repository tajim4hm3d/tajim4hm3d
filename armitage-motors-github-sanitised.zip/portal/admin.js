/* Northstar Motors: owner stock management */
const $ = id => document.getElementById(id);
const safe = value => String(value == null ? '' : value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const assetUrl = u => String(u).startsWith('assets/') ? '/' + u : u;
const gbp = n => n == null ? 'Price on request' : new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP',maximumFractionDigits:0}).format(n);
const store = window.AMStore;
let allCars=[];
let editingId=null;
let photosDraft=[];
let busy=false;
let toastTimer=null;
function toast(message, error=false){
  const t=$('toast');t.textContent=message;t.style.borderLeft=`4px solid ${error?'#c95858':'#b68c5d'}`;t.classList.add('show');
  if(toastTimer)clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),5100);
}
function disabled(value){busy=value;$('save-car').disabled=value;$('add-car').disabled=value;$('photo-files').disabled=value;}
function label(status){return status==='sold'?'Sold':status==='draft'?'Draft':'Available';}
function setVisible(id,shown){$(id).hidden=!shown;}
async function init(){
  if(store.mode==='unconfigured'){
    setVisible('blocked-panel',true);
    $('blocked-message').textContent='Cloudflare Access has not been configured for this portal. See SETUP.md.';
    return;
  }
  if(store.mode==='demo'){
    $('mode-notice').hidden=false;
    $('mode-notice').innerHTML='<strong>LOCAL DEMO MODE</strong> — No password protection or shared database yet. Changes stay in this browser on this computer. Do not use this mode as a live owner portal.';
    setVisible('dashboard',true);await reload();return;
  }
  try {
    const user=await store.user();
    if(user){if(await store.isAdmin()){await showDashboard();return;}
      setVisible('blocked-panel',true);$('blocked-message').textContent='Your account is signed in but is not authorised as a dealership administrator. Ask the site administrator to add your email to the authorised owner list in Cloudflare.';setVisible('logout',true);return;}
  } catch(e){console.error(e);}
  setVisible('blocked-panel',true);$('blocked-message').textContent='Access verification is required. The owner must sign in through Cloudflare Access.';
}
async function showDashboard(){
  setVisible('login-panel',false);setVisible('blocked-panel',false);setVisible('dashboard',true);setVisible('logout',true);
  await reload();
}
async function reload(){
  try{allCars=await store.list();render();$('starter').hidden=!(store.mode==='cloudflare'&&allCars.length===0);}catch(e){console.error(e);toast(e.message||'Unable to fetch stock',true);}
}
function render(){
  $('stat-total').textContent=allCars.length;
  $('stat-available').textContent=allCars.filter(c=>!c.status||c.status==='available').length;
  $('stat-sold').textContent=allCars.filter(c=>c.status==='sold').length;
  $('stat-draft').textContent=allCars.filter(c=>c.status==='draft').length;
  const query=$('stock-search').value.trim().toLowerCase(),status=$('status-filter').value;
  const rows=allCars.filter(c=>(!status||(c.status||'available')===status)&&(!query||(`${c.make} ${c.model} ${c.trim||''} ${c.year||''}`).toLowerCase().includes(query)));
  $('list-empty').hidden=rows.length>0;
  $('vehicle-list').innerHTML=rows.map(car=>{
    const status=car.status||'available';
    const first=car.photos?.[0]||car.photo||'';
    const validPic=first.startsWith('assets/')||first.startsWith('/media/')||first.startsWith('data:image/')||first.startsWith('https://');
    const img=validPic?`<img class="vehicle-thumb" src="${safe(assetUrl(first))}" alt="">`:'<div class="vehicle-thumb">NO PHOTO</div>';
    return `<div class="vehicle-row" data-id="${car.id}">
      ${img}
      <div class="vehicle-name"><strong>${safe(car.make+' '+car.model)}</strong><span>${safe((car.year||'Year TBC')+' · '+(car.mileage==null?'Mileage TBC':Number(car.mileage).toLocaleString('en-GB')+' miles'))}</span></div>
      <div class="vehicle-price">${gbp(car.price)}</div>
      <div><span class="pill pill-${status}">${label(status)}</span></div>
      <div class="row-actions"><button class="tiny-btn" type="button" data-action="edit">Edit</button><button class="tiny-btn ${status==='sold'?'':'sold-action'}" type="button" data-action="status">${status==='sold'?'Mark available':'Mark sold'}</button><button class="tiny-btn remove" type="button" data-action="delete">Delete</button></div>
    </div>`;
  }).join('');
}
function setForm(name, value){const el=$('vehicle-form').elements.namedItem(name);if(el)el.value=value==null?'':value;}
function openEditor(car){
  editingId=car?.id||Date.now();
  $('vehicle-form').reset();
  $('editor-title').textContent=car?'Edit vehicle':'Add a vehicle';
  for(const name of ['make','model','year','trim','price','mileage','fuel','gearbox','colour','power','description','sellerNote','sourceUrl'])setForm(name,car?.[name]);
  setForm('status',car?.status||'available');
  setForm('features',(car?.features||[]).join('\n'));
  setForm('history',(car?.history||[]).join('\n'));
  photosDraft=[...(car?.photos||[])];
  $('photo-files').value='';$('photo-progress').textContent='';renderPhotos();
  $('editor-overlay').hidden=false;document.body.classList.add('editor-open');
  $('vehicle-form').elements.namedItem('make').focus();
}
function closeEditor(){if(busy)return;$('editor-overlay').hidden=true;document.body.classList.remove('editor-open');}
function renderPhotos(){
  $('photos-preview').innerHTML=photosDraft.map((url,i)=>`<div class="photo-chip ${i===0?'is-main':''}">
    <img src="${safe(assetUrl(url))}" alt="Vehicle photo ${i+1}">
    <div class="photo-controls">
      <button type="button" data-move-photo="${i}" data-direction="-1" ${i===0?'disabled':''} aria-label="Move photo ${i+1} left">←</button>
      <button type="button" data-move-photo="${i}" data-direction="1" ${i===photosDraft.length-1?'disabled':''} aria-label="Move photo ${i+1} right">→</button>
      <button type="button" data-remove-photo="${i}" aria-label="Remove photo ${i+1} from listing">×</button>
    </div>
    <span>${i===0?'Main photo':`Photo ${i+1}`}</span>
  </div>`).join('');
}
async function doSave(event){
  event.preventDefault();if(busy)return;
  const form=$('vehicle-form'),f=new FormData(form);
  const string=k=>String(f.get(k)||'').trim();
  const number=k=>string(k)===''?null:Number(string(k));
  const lines=k=>string(k).split('\n').map(x=>x.trim()).filter(Boolean);
  const old=allCars.find(c=>c.id===editingId)||{};
  const car={...old,id:editingId,make:string('make'),model:string('model'),trim:string('trim'),year:number('year'),price:number('price'),mileage:number('mileage'),fuel:string('fuel'),gearbox:string('gearbox'),colour:string('colour'),power:string('power'),status:string('status')||'available',description:string('description'),features:lines('features'),history:lines('history'),sellerNote:string('sellerNote'),sourceUrl:string('sourceUrl'),photos:[...photosDraft],isDemo:false};
  if(!car.make||!car.model){toast('Make and model are required',true);return;}
  try {disabled(true);await store.save(car);await reload();$('editor-overlay').hidden=true;document.body.classList.remove('editor-open');toast(`${car.make} ${car.model} saved successfully`);}
  catch(e){toast(`Save failed: ${e.message}`,true)}finally{disabled(false)}
}
async function changeStatus(car){
  const old=car.status||'available';const next=old==='sold'?'available':'sold';
  try{await store.save({...car,status:next});await reload();toast(`${car.make} ${car.model} marked ${next.toUpperCase()}`);}
  catch(e){toast('Could not update status: '+e.message,true);}
}
async function deleteCar(car){
  if(!confirm(`Permanently delete ${car.make} ${car.model} from the website?`))return;
  try{await store.remove(car.id);await reload();toast('Vehicle deleted');}
  catch(e){toast('Delete failed: '+e.message,true);}
}
$('vehicle-list').addEventListener('click',async e=>{
  const target=e.target.closest('[data-action]');if(!target||busy)return;
  const row=target.closest('[data-id]'),car=allCars.find(c=>c.id===Number(row.dataset.id));if(!car)return;
  if(target.dataset.action==='edit')openEditor(car);
  if(target.dataset.action==='status')await changeStatus(car);
  if(target.dataset.action==='delete')await deleteCar(car);
});
$('add-car').addEventListener('click',()=>openEditor(null));
$('vehicle-form').addEventListener('submit',doSave);
$('editor-cancel').addEventListener('click',closeEditor);
$('editor-close').addEventListener('click',closeEditor);
$('editor-dim').addEventListener('click',closeEditor);
$('photos-preview').addEventListener('click',e=>{
  const remove=e.target.closest('[data-remove-photo]');
  if(remove){photosDraft.splice(Number(remove.dataset.removePhoto),1);renderPhotos();return;}
  const move=e.target.closest('[data-move-photo]');
  if(move){
    const i=Number(move.dataset.movePhoto),next=i+Number(move.dataset.direction);
    if(next>=0&&next<photosDraft.length){[photosDraft[i],photosDraft[next]]=[photosDraft[next],photosDraft[i]];renderPhotos();}
  }
});
$('photo-files').addEventListener('change',async e=>{
  const files=[...e.target.files];if(!files.length)return;
  if(photosDraft.length+files.length>40){toast('A vehicle can have up to 40 photos. Remove some before adding more.',true);e.target.value='';return;}
  try{
    disabled(true);
    for(let i=0;i<files.length;i++){
      $('photo-progress').textContent=`Uploading photo ${i+1} of ${files.length}…`;
      const url=await store.uploadPhoto(files[i],editingId);photosDraft.push(url);renderPhotos();
    }
    $('photo-progress').textContent=`${files.length} image(s) added — click Save vehicle to keep these changes.`;
  }catch(err){$('photo-progress').textContent='Upload failed: '+err.message;toast(err.message,true);}
  finally{disabled(false);$('photo-files').value='';}
});
$('stock-search').addEventListener('input',render);
$('status-filter').addEventListener('change',render);
$('login-form').addEventListener('submit',async e=>{
  e.preventDefault();const btn=e.target.querySelector('button');btn.disabled=true;$('login-error').textContent='';
  try{await store.signIn($('login-email').value,$('login-password').value);if(!(await store.isAdmin()))throw Error('This account is not approved as an owner/admin.');await showDashboard();$('login-password').value='';}
  catch(err){$('login-error').textContent=err.message||'Unable to sign in';}
  finally{btn.disabled=false;}
});
$('logout').addEventListener('click',async()=>{await store.logout();});
$('import-starter').addEventListener('click',async()=>{if(!confirm('Import the 6 prepared car listings into the live database?'))return;try{await store.importStarter();await reload();toast('Starter cars imported successfully');}catch(e){toast(e.message,true);}});
window.addEventListener('storage',e=>{if(store.mode==='demo'&&e.key===store.LOCAL_KEY)reload();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('editor-overlay').hidden)closeEditor();});
init();
