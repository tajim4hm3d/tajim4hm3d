# Architecture (production system)

```mermaid
flowchart TD
    A[Customer browser] --> B[Cloudflare Pages website]
    B --> C[Pages Functions]
    C --> D[(Cloudflare D1 vehicle records)]
    C --> E[(Cloudflare R2 photographs)]
    F[Owner browser] --> G[Cloudflare Access]
    G --> H[Stock management portal]
    H --> C
    B --> I[Cloudflare Turnstile]
    I --> C
    C --> J[Resend email API]
    J --> K[Dealership inbox]
```

## Data flow

- **Public stock:** customer browser -> public Pages Function -> D1 vehicle data -> image URLs served from R2 through a Pages Function.
- **Management:** owner signs in with Cloudflare Access; backend verifies Access JWT and allowlisted identity before stock edits and photo uploads.
- **Enquiries:** browser completes Turnstile; server checks token and validates fields before sending through Resend.
- **Portfolio demo:** no external data access. `config.js` forces browser-only stock using fictional records and disables outgoing forms.

## Bound resources (not included)

The live client's D1 database, R2 bucket contents, access configuration, sender credentials and customer enquiries are **not distributed**. To build a new independent production deployment, create your own Cloudflare resources and use the placeholder configuration names in `.env.example`.
