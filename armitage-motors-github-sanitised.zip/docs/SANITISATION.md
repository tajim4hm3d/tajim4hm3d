# What was removed before GitHub publication

- All real vehicle records and seller-provided details: replaced with fictional sample cars.
- Client car photographs, Marketplace source links and listing screenshots.
- Actual customer enquiries, contact records, recipient emails and API credentials.
- Client phone numbers, showroom address and business profile configuration.
- Live-client access details, audience tags and account allowlists.
- Production database dumps and object-storage contents (neither is present).
- Client-specific setup notes and deployment changelogs.

Only AI-generated illustrative service/hero artwork is retained.

**Important:** The code shows architecture and generic implementation patterns. It is not a copy of production data or a production-ready, permission-free redistribution of the client's business assets. Ask the client before publishing any proprietary implementation code. Start with a PRIVATE GitHub repository if approval is not yet confirmed.
